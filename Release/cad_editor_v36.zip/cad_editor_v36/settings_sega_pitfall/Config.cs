using CadEditor;
using System.Collections.Generic;
using System.Drawing;

public class Config
{
  public string getFileName()      {  return "Pitfall - The Mayan Adventure (U) [!].gen";                     }
  public string getDumpName()      { return "settings_sega_pitfall/SegaPitfall_1_extract.bin";     }
  public string getConfigName()    { return "settings_sega_pitfall/Settings_Pitfall-1.cs"; }
  public bool showDumpFileField()  { return true;  }
}