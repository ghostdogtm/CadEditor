using CadEditor;
using System.Collections.Generic;
using System.Drawing;

public class Config
{
  public string getFileName()      {  return "settings_sega_world_of_illusion/dump.bin";         }
  public string getDumpName()      { return "";                                                  }
  public string getConfigName()    { return "settings_sega_world_of_illusion/Settings_WIL-1.cs"; }
  public bool showDumpFileField()  { return false;  }
}